package mapa.frame;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import mapa.Mapa;
import mapa.frame.sprite.Sprite;

public class Frame implements Runnable {

	private int tipo;
	private ArrayList<Sprite> sprites;
	private int spriteMostrado;

	private int x;
	private int y;
	private Mapa mapa;
	private Thread actualizaciones;

	public Frame(int id, int x, int y, Mapa mapa) {

		this.mapa = mapa;
		this.sprites = new ArrayList<>();
		this.spriteMostrado = 0;
		this.x = x;
		this.y = y;

		try {

			JsonParser parser = new JsonParser();
			FileReader fr = new FileReader("recursos/mapa/frames.json");
			JsonElement data = parser.parse(fr);
			JsonObject frame = data.getAsJsonObject().get("frames").getAsJsonArray().get(id).getAsJsonObject();

			this.tipo = frame.get("tipo").getAsInt();

			Iterator<JsonElement> it = frame.get("sprites").getAsJsonArray().iterator();

			while (it.hasNext()) {
				Sprite sprite = mapa.getSprite(it.next().getAsInt());
				this.sprites.add(sprite);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		// creamos he incializamos el thread
		// que se encargara de las actualizaciones
		this.actualizaciones = new Thread(this);
		actualizaciones.start();

	}

	/*
	 * 
	 */
	public void mostrar() {

		int[] pixeles = this.sprites.get(spriteMostrado).getPixeles();
		int ancho = (int) Math.sqrt(pixeles.length);

		for (int y = 0; y < ancho; y++) {
			for (int x = 0; x < ancho; x++) {
				mapa.setPixeles((this.x + x) + (this.y + y) * (mapa.getAncho() * 32), pixeles[x + y * ancho]);
			}
		}

	}

	public void rotarSprite() {

		// elegir sprite que toca
		if (spriteMostrado < sprites.size() - 1) {
			spriteMostrado++;
		} else {
			spriteMostrado = 0;
		}

	}

	public int getTipo() {
		return tipo;
	}

	@Override
	public void run() {

		// se inicia al crear la clase
		// inciar bucle y actuaciones
		// System.out.println("Aki");

	}

}
