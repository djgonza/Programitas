package mapa.frame;

import java.awt.Color;
import java.util.ArrayList;

import mapa.Mapa;
import mapa.frame.sprite.Sprite;

public class Frame {

	private ArrayList<Sprite> sprites;

	private int x;
	private int y;
	private Mapa mapa;

	public Frame(int x, int y, Mapa mapa) {

		this.mapa = mapa;
		this.sprites = new ArrayList<>();
		this.x = x;
		this.y = y;

	}

	/*
	 * carga los pixeles de los sprites en el mapa
	 */
	public void mostrar() {

		for (Sprite sprite : sprites) {

			Color[] pixeles = sprite.getPixeles();
			int ladoSprite = (int) Math.sqrt(pixeles.length);

			for (int y = 0; y < ladoSprite; y++) {
				for (int x = 0; x < ladoSprite; x++) {

					Color color = pixeles[x + y * ladoSprite];
					if (color.getAlpha() != 0)
						mapa.setPixeles((this.x + x) + (this.y + y) * mapa.getAncho(), color.getRGB());

				}
			}

		}

	}

	public void addSprite(Sprite sprite) {
		this.sprites.add(sprite);
	}

}
