package mapa.frame.sprite;

import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Sprite {

	private int[] pixeles;

	public Sprite(int idSprite) {

		try {

			JsonParser parser = new JsonParser();
			FileReader fr = new FileReader("recursos/texturas/sprites.json");
			JsonElement data = parser.parse(fr);
			JsonObject sprite = data.getAsJsonObject().get("sprites").getAsJsonArray().get(idSprite).getAsJsonObject()
					.getAsJsonObject("sprite");

			BufferedImage imagen = ImageIO
					.read(new FileInputStream("recursos/texturas/" + sprite.get("hojaSprite").getAsString() + ".png"));
			this.pixeles = imagen.getRGB(sprite.get("columna").getAsInt() * 32, sprite.get("fila").getAsInt() * 32,
					sprite.get("ancho").getAsInt(), sprite.get("alto").getAsInt(), null, 0,
					sprite.get("ancho").getAsInt());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public int[] getPixeles() {
		return pixeles;
	}

}
