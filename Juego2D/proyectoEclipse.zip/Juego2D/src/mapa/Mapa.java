package mapa;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import control.Teclado;
import graficos.Pantalla;
import mapa.frame.Frame;
import mapa.frame.sprite.Sprite;

public class Mapa {

	private Pantalla pantalla;
	private Teclado teclado;

	private String zona;
	private int ancho;
	private int alto;

	private int[] pixeles;
	private int[] pixelesLogicos;

	private int x;
	private int y;

	private HashMap<Integer, Sprite> sprites;
	private ArrayList<Frame> frames;

	public Mapa(Pantalla pantalla, Teclado teclado) {

		this.pantalla = pantalla;
		this.teclado = teclado;

		this.sprites = new HashMap<>();
		this.frames = new ArrayList<>();

		// cargarZona("base");
		generarMapaAleatorio();
		actualizar();

	}

	private void cargarZona(String zona) {

		try {

			JsonParser parser = new JsonParser();
			FileReader fr = new FileReader("recursos/mapa/zonas/" + zona + ".json");
			JsonObject data = parser.parse(fr).getAsJsonObject().get(zona).getAsJsonObject();

			this.alto = data.get("alto").getAsInt();
			this.ancho = data.get("ancho").getAsInt();
			this.pixeles = new int[(alto << 5) * (ancho << 5)];

			this.x = (pantalla.getWidth() / 2) - (data.get("x").getAsInt() << 5);
			this.y = (pantalla.getHeight() / 2) - (data.get("y").getAsInt() << 5);

			JsonArray framesMapa = data.get("frames").getAsJsonArray();

			for (int y = 0; y < alto; y++) {
				for (int x = 0; x < ancho; x++) {
					frames.add(new Frame(framesMapa.get(x + y * ancho).getAsInt(), x << 5, y << 5, this));
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

	private void generarMapaAleatorio() {
		Random aleatorio = new Random();
		this.alto = 50;
		this.ancho = 50;
		this.x = (pantalla.getWidth() / 2) - (5 << 5);
		this.y = (pantalla.getHeight() / 2) - (5 << 5);
		this.pixeles = new int[(alto << 5) * (ancho << 5)];
		for (int y = 0; y < alto; y++) {
			for (int x = 0; x < ancho; x++) {
				frames.add(new Frame(aleatorio.nextInt(20), x << 5, y << 5, this));
			}
		}
	}

	public void mostrar() {

		actualizarCoordenadas();

		int anchoPantalla = pantalla.getWidth();
		int altoPantalla = pantalla.getHeight();

		for (int y = 0; y < altoPantalla; y++) {
			for (int x = 0; x < anchoPantalla; x++) {

				// comprobacion para no salirnos del array
				if (x >= (ancho << 5) - 1 || y > (alto << 5) - 1) {
					break;
				}

				if (x + this.x > 0 && x + this.x - anchoPantalla < 0)
					pantalla.setPixel((x + this.x) + (y + this.y) * anchoPantalla, pixeles[x + y * (ancho << 5)]);

			}
		}

	}

	private void actualizarCoordenadas() {

		if (teclado.arriva)
			y++;
		if (teclado.abajo)
			y--;
		if (teclado.izquierda)
			x++;
		if (teclado.derecha)
			x--;

		// System.out.println(x + " : " + y);

	}

	public void actualizar() {
		Iterator<Frame> it = frames.iterator();
		while (it.hasNext()) {
			it.next().mostrar();
		}
	}

	/*
	 * devuelve un sprite de la lista, si no existe lo crea
	 */
	public Sprite getSprite(int idSprite) {
		if (sprites.get(idSprite) == null) {
			Sprite sprite = new Sprite(idSprite);
			sprites.put(idSprite, sprite);
		}
		return sprites.get(idSprite);
	}

	public void setPixeles(int indice, int valor) {
		if (indice > 0 && indice < pixeles.length)
			this.pixeles[indice] = valor;
	}

	public int getAncho() {
		return ancho;
	}

	public int getAlto() {
		return alto;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void aumentarX() {
		x++;
		mostrar();
	}

	public void aumentarY() {
		y++;
		mostrar();
	}

	public void decrementarX() {
		x--;
		mostrar();
	}

	public void decrementarY() {
		y--;
		mostrar();
	}

}
